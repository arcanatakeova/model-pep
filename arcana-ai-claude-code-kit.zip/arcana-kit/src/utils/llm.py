"""OpenRouter LLM client with model routing and SOUL.md injection.
Read docs/ARCHITECTURE.md before modifying."""
# TODO: Implement OpenRouter client
# - Load SOUL.md as system prompt
# - Route: Haiku for routine, Sonnet for decisions, Opus for strategy
# - All calls through OpenRouter API, never direct
