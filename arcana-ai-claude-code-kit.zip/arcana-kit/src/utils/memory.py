"""Supabase pgvector memory system.
Read docs/ARCHITECTURE.md before modifying."""
# TODO: Implement memory system
# - embed() — Convert text to 1536-dim vector via OpenAI ada-002
# - store() — Insert content + embedding + category + importance
# - recall() — match_memories() function for similarity search
