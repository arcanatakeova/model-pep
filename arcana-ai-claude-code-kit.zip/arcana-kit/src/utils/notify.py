"""Discord/Telegram notification system.
Alerts Ian & Tan on trades, leads, errors, and daily summaries."""
# TODO: Implement notification system
